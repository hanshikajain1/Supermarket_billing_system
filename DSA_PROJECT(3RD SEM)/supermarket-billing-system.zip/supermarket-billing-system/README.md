# Supermarket Billing System

A console billing application for a supermarket, written in **Java**.
Customers join a billing queue, prices are looked up in a HashMap, and the last scanned
item can be removed with a stack. Every bill is saved to `bills.txt`.

**Project PS 12 - Data Structures and Algorithms (DSA)**
Rungta International Skills University, School of Computer Science and Engineering

| | |
|---|---|
| Student | Hanshika Jain (ERP ID 10543) |
| Programme | B.Tech CSE (AI & ML) in association with Google |
| Guide | Ms. Naina Singh |

## Data structures used

| Concept | Where it is used | Why |
|---|---|---|
| **Queue** (`LinkedList`) | `billingQueue` | Customers are served first-come, first-served (FIFO) |
| **HashMap** | `priceList` (name to price) | Item price lookup in O(1) on average |
| **Stack** | `cartStack` | The last scanned item is removed first (undo, LIFO) |
| **Array** | `PRODUCT_NAMES`, `PRODUCT_PRICES`, `MENU` | Catalogue that fills the HashMap, and the menu text |
| **File handling** | `loadBills()`, `saveBills()` | Bills are loaded from `bills.txt` at start and saved after each bill and on exit |

Price list: Rice 60, Milk 30, Bread 40.

## Features (methods)

| Menu | Method | What it does |
|---|---|---|
| 1 | `addCustomer()` | Adds a customer to the rear of the queue and shows their position |
| 2 | `billNextCustomer()` | Bills the front customer; refuses if the queue is empty |
| 2 (inside) | `undoLastItem()` | Type `Undo` to remove the last scanned item |
| 3 | `viewQueue()` | Lists waiting customers, front to rear |
| 4 | `viewSavedBills()` | Shows bills loaded from / saved to the file |
| 5 | exit | Saves `bills.txt` and quits |

While billing, enter items as `Milk x2`, `Milk 2` or `Milk`, then `Done` to finish.

## How to run

Requires JDK 11 or later.

```bash
git clone https://github.com/<your-username>/supermarket-billing-system.git
cd supermarket-billing-system
javac -d build src/Main.java
cd build
java Main
```

Run all test inputs at once: `sh tests/run_tests.sh`

## Test cases (from the project description)

| # | Input | Expected output |
|---|---|---|
| 1 Normal | Menu 1, name `Riya` | `Riya added to billing queue. Position: 1` |
| 2 Boundary | Queue has only Riya; menu 2; `Rice x1`; `Done` | `Bill for Riya: Rice x1 = 60 \| Total 60` then `Queue is now empty.` |
| 3 Invalid | Menu 2; item `Chocolate` | `Item Chocolate not found in price list.` |
| 4 Different | Queue Riya, Aman; menu 2; `Milk x2`, `Bread x1`, `Undo`, `Done`; menu 3 | `Last item Bread removed.` / `Bill for Riya: Milk x2 = 60 \| Total 60` / `1. Aman` |
| 5 Empty queue | Menu 2 with nobody waiting | `Queue is empty. Cannot bill.` |

Ready-made inputs are in [`tests/`](tests).

### Sample run (test case 4)

```
Choice: Name: Riya added to billing queue. Position: 1
Choice: Name: Aman added to billing queue. Position: 2
Choice: Billing: Riya
Item: Added Milk x2
Item: Added Bread x1
Item: Last item Bread removed.
Item: Bill for Riya: Milk x2 = 60 | Total 60
Choice: 1. Aman
```

## Time complexity

| Operation | Structure | Complexity |
|---|---|---|
| Add customer | `Queue.offer()` | O(1) |
| Price lookup | `HashMap.get()` | O(1) average |
| Scan item / undo | `Stack.push()` / `pop()` | O(1) |
| Serve customer | `Queue.poll()` | O(1) |
| Build bill | traverse cart | O(K), K = items in cart |
| View queue | traverse queue | O(C), C = customers waiting |

## Repository layout

```
supermarket-billing-system/
├── src/Main.java        # complete solution (one file)
├── tests/               # test inputs + run_tests.sh
├── docs/                # interim report and presentation
├── .gitignore
└── README.md
```

## Future scope

GST and discounts, stock management, a GUI (Swing/JavaFX), a database, multiple counters, sales reports.
