#!/bin/sh
# Runs each tcN_input.txt through Main and prints the output (compare with README "Test cases").
# Usage: sh tests/run_tests.sh   (from the repository root; needs JDK 11+)
cd "$(dirname "$0")/.." || exit 1
mkdir -p build && javac -d build src/Main.java || exit 1
cd build || exit 1
for f in ../tests/tc*_input.txt; do
  echo "=============== $f"
  rm -f bills.txt
  java -cp . Main < "$f"
done
rm -f bills.txt
